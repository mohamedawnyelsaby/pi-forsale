Pi-forsale Deployment Upgrade Files

## pi-forsale-backend/Dockerfile
```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm install --production
COPY . .
EXPOSE 4000
CMD ["node", "server.js"]
```

## pi-forsale-frontend/Dockerfile
```dockerfile
FROM node:18-alpine AS builder
WORKDIR /app
COPY package*.json ./
RUN npm install
COPY . .
RUN npm run build

FROM nginx:alpine
COPY --from=builder /app/dist /usr/share/nginx/html
EXPOSE 80
```

## docker-compose.yml
```yaml
version: "3.9"
services:
  frontend:
    build: ./pi-forsale-frontend
    ports:
      - "80:80"
    restart: always

  backend:
    build: ./pi-forsale-backend
    ports:
      - "4000:4000"
    restart: always
```

## api/chat.js (AI Router)
```js
const express = require("express");
const router = express.Router();
require("dotenv").config();

router.post("/", async (req, res) => {
  try {
    const { message } = req.body;

    if (!message) {
      return res.status(400).json({ error: "Missing message" });
    }

    const aiResponse = {
      reply: `AI Response for: ${message}`,
    };

    res.json(aiResponse);
  } catch (error) {
    res.status(500).json({ error: "AI Server Error", details: error.message });
  }
});

module.exports = router;
```

## backend/server.js (Connected AI Route)
```js
const express = require("express");
const app = express();
const cors = require("cors");
require("dotenv").config();

app.use(cors());
app.use(express.json());

app.use("/api/chat", require("./api/chat"));

app.get("/", (req, res) => {
  res.send("Backend Running with AI Layer ✔");
});

app.listen(4000, () => console.log("Backend Live on port 4000"));
```

## frontend/src/lib/ai.js
```js
export async function askAI(message) {
  const res = await fetch("https://yourdomain.com/api/chat", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ message }),
  });

  return await res.json();
}
```
